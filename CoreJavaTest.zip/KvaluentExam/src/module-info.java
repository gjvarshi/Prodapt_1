module KvaluentExam {
}