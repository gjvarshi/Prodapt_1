package TelecomLayer1;

public class CallRecordFetcher {
	public void fetchCallRecords() {
	   }
 
}