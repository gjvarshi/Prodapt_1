package TelecomLayer1;



public class InvoiceGenerator {
	 public static void generateInvoice() {
	       System.out.println("Generating Invoice...");
	     
	   }
}
 