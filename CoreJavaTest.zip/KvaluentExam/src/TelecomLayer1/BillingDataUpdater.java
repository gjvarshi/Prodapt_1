package TelecomLayer1;


	public class BillingDataUpdater {
		   public void updateBillingData() {
		       
		   }
	 
}
